const operand1=document.getElementById('operand1');
const operand2=document.getElementById('operand2');
const operators=document.getElementsByName("operator")
const output=document.getElementById('output');
const btn=document.getElementById('btn');